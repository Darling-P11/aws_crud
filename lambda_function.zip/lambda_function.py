# lambda_function.py

import json
import requests

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    # Detectar tipo por nombre (simulado)
    if "factura" in key.lower():
        tipo = "Factura"
        descripcion = "Imagen clasificada como Factura"
    elif "documento" in key.lower():
        tipo = "Documento"
        descripcion = "Imagen clasificada como Documento"
    else:
        tipo = "Otro"
        descripcion = "Imagen genérica"

    # Llamar al backend Django
    url = "http://98.81.108.241/api/imagenes/"
    data = {
        "nombre": key,
        "tipo_detectado": tipo,
        "descripcion": descripcion
    }
    try:
        response = requests.post(url, json=data)
        return {
            "statusCode": response.status_code,
            "body": response.text
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": str(e)
        }
